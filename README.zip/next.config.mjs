/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
        reactRefresh: false
    }
};

export default nextConfig;
