(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_compiled_react-dom_1f56dc._.js",
    "static/chunks/node_modules_next_dist_compiled_107ce8._.js",
    "static/chunks/node_modules_next_dist_client_523921._.js",
    "static/chunks/node_modules_next_dist_4bb10e._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_00636a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d0a96d._.js"
  ],
  "source": "entry"
});
