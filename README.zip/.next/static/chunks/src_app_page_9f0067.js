(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_9f0067.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_9f0067.js",
  "chunks": [
    "static/chunks/src_c8b874._.js",
    "static/chunks/node_modules_next_93e1a0._.js",
    "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa.js",
    "static/chunks/node_modules_24edb3._.js",
    "static/chunks/src_app_page_module_d12eb7.css"
  ],
  "source": "dynamic"
});
