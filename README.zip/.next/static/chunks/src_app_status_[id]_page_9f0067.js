(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_status_[id]_page_9f0067.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_status_[id]_page_9f0067.js",
  "chunks": [
    "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa.js",
    "static/chunks/node_modules_a2c3fb._.js",
    "static/chunks/src_724d65._.js",
    "static/chunks/src_app__components_ProgressBar_progress_12e1f6.css"
  ],
  "source": "dynamic"
});
