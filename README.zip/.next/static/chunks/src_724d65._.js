(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_724d65._.js", {

"[project]/src/lib/firebase/config.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Import the functions you need from the SDKs you need
__turbopack_esm__({
    "db": (()=>db)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/app/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/@firebase/app/dist/esm/index.esm2017.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
;
;
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAd8-8ioY9e4d4ALS9Xz1wj6cfYpPiytfI",
    authDomain: "loanapp-7dd0d.firebaseapp.com",
    projectId: "loanapp-7dd0d",
    storageBucket: "loanapp-7dd0d.firebasestorage.app",
    messagingSenderId: "469537897851",
    appId: "1:469537897851:web:45310ec7402c3d913791de"
};
// Initialize Firebase
const app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["initializeApp"])(firebaseConfig);
const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/_components/ProgressBar/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/firebase/config.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
const ProgressBar = ()=>{
    _s();
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [currentApplication, setCurrentApplication] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const messageDivRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    let payProcessingContent = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Important Update: Next Steps for Your Loan Disbursement</h2>
    
    <p>Dear <strong>${currentApplication.name}</strong>,</p>
    
    <p>Congratulations! We are pleased to inform you that your loan application has been reviewed by our team and is currently under process. To ensure the smooth disbursement of your loan, there are a few critical steps to complete.</p>
    
    <h3 style="color: #0056b3;">Mandatory Fees for Loan Disbursement</h3>
    <p>To proceed with the loan disbursement, it is essential to pay the following fees:</p>
    
    <ol>
        <li>
            <strong>Processing Fee</strong>: This fee covers the administrative costs associated with handling and processing your loan application.
            <ul>
                <li><strong>Amount:</strong> ${currentApplication.processingFee}</li>
                <li><strong>Purpose:</strong> Ensures that all necessary documentation, evaluation, and verification are conducted accurately and efficiently.</li>
            </ul>
        </li>
        <li>
            <strong>Insurance Fee</strong>: This fee provides coverage to secure your loan and mitigate risks.
            <ul>
                <li><strong>Amount:</strong> ${currentApplication.insuranceFee}</li>
                <li><strong>Purpose:</strong> Safeguards both you and the lender in case of unforeseen circumstances.</li>
            </ul>
        </li>
    </ol>
    
    <p><strong>Please note that the payment of these fees is mandatory and must be completed before your loan can be disbursed.</strong></p>
    
    <h3 style="color: #0056b3;">How to Make the Payments</h3>
    <ol>
        <li>
            <strong>Processing Fee Payment:</strong>
            <ul>
                <li>Transfer the fee amount to the following account:</li>
                <ul>
                    <li><strong>Account Name:</strong> ${currentApplication.name}</li>
                    <li><strong>Account Number:</strong> ${currentApplication.bankaccount}</li>
                    <li><strong>Bank Name:</strong> ${currentApplication.bankname}</li>
                    <li><strong>IFSC Code:</strong> ${currentApplication.bankifsc}</li>
                </ul>
                <li>Once the payment is made, kindly send a confirmation receipt to <a href="mailto:support@shaniloan.in">support@dhaniloan.in</a>.</li>
            </ul>
        </li>
        <li>
            <strong>Insurance Fee Payment:</strong>
            <ul>
                <li>The insurance fee can be paid using any of the following methods:</li>
                <ul>
                    <li>Our support team will contact you soon and guide you through the payment</li>
                </ul>
                <li>After the payment, please upload the proof of payment on your loan dashboard or email it to <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a>.</li>
            </ul>
        </li>
    </ol>
    
    <h3 style="color: #0056b3;">Next Steps After Payment</h3>
    <p>
        Once the fees are successfully received, our team will update your application status within <strong>24 hours</strong>.
        A representative from our support team will contact you to confirm the details and provide further instructions regarding the disbursement process.
    </p>
    
    <p>We emphasize the importance of completing these payments at the earliest to avoid delays in your loan disbursement. Should you have any questions or require assistance with the payment process, feel free to contact our customer support team at <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a>.</p>
    
    <p>Thank you for choosing <strong>Dhani Finance PVT LTD</strong> as your trusted financial partner. We look forward to serving you.</p>
</div>
`;
    let applicationReviewedHtml = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Loan Application Received</h2>

    <p>Dear <strong>${currentApplication.name}</strong>,</p>

    <p>Thank you for submitting your loan application. We are pleased to inform you that it has been <strong>successfully received</strong> and is currently under review by our loan department.</p>

    <h3 style="color: #0056b3;">What Happens Next?</h3>
    <p>Please allow some time for the necessary <strong>assessments</strong> and <strong>processing</strong> to be completed. Our team is thoroughly reviewing your application to ensure all required details and documentation meet the standards necessary for approval.</p>

    <p>Once the review process is completed and your loan status has been updated, a member of our team will promptly contact you. They will provide further information regarding your application and discuss the next steps, if necessary.</p>

    <h3 style="color: #0056b3;">We Appreciate Your Patience</h3>
    <p>We understand that this is an important process for you, and we are committed to handling your application with the utmost care and diligence. Your patience and understanding during this time are greatly appreciated.</p>

    <p>If you have any questions or need assistance while your application is under review, please do not hesitate to contact our support team at <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a>.</p>

    <p>Thank you for choosing <strong>Dhani Finance PVT LTD</strong> as your financial partner. We look forward to serving you.</p>
</div>
`;
    let underProcessHtml = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Loan Application Update</h2>

    <p>Dear <strong>${currentApplication.name}</strong>,</p>

    <p><strong>Congratulations!</strong> We are pleased to inform you that your loan application has been <strong>reviewed</strong> by our team and is now under process.</p>

    <h3 style="color: #0056b3;">What You Can Expect</h3>
    <p>Please allow some time while we update your application status. This process typically takes up to <strong>24 hours</strong>. After the update is completed, a member of our support team will contact you to provide further details or discuss the next steps in your loan journey.</p>

    <p>We are committed to ensuring a smooth and efficient process and appreciate your patience during this time.</p>

    <h3 style="color: #0056b3;">Need Assistance?</h3>
    <p>If you have any questions or need further assistance, please do not hesitate to reach out to our support team at <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a>.</p>

    <p>Thank you for choosing <strong>Dhani Finance PVT LTD</strong> as your trusted financial partner. We look forward to assisting you further.</p>
</div>
`;
    let loanApprovedHtml = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Loan Approval Notification</h2>

    <p>Dear <strong>${currentApplication.name}</strong>,</p>

    <p><strong>Congratulations!</strong> We are thrilled to inform you that your loan application has been <strong>approved</strong> by our team.</p>

    <h3 style="color: #0056b3;">What Happens Next?</h3>
    <p>Our team will now proceed with the final steps to disburse the approved loan amount to your designated bank account. You will receive an official notification once the disbursement process has been completed.</p>

    <h3 style="color: #0056b3;">Important Note</h3>
    <p>Please ensure that all required formalities, including submission of any remaining documents or payment of applicable processing fees, are completed at the earliest to avoid any delays.</p>

    <h3 style="color: #0056b3;">Need Assistance?</h3>
    <p>If you have any questions or need further assistance, please feel free to reach out to our support team at <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a> or call us at <strong>[Support Phone Number]</strong>.</p>

    <p>Thank you for choosing <strong>Dhani Finance PVT LTD</strong> as your trusted financial partner. We are committed to providing you with exceptional service and support throughout your loan journey.</p>
</div>
`;
    let loanDisbursedHtml = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Loan Disbursement Notification</h2>

    <p>Dear <strong>${currentApplication.name}</strong>,</p>

    <p><strong>Congratulations!</strong> We are pleased to inform you that your loan has been successfully <strong>disbursed</strong> and the approved amount has been transferred to your designated bank account.</p>

    <h3 style="color: #0056b3;">What to Expect Next?</h3>
    <p>We recommend that you check your account for the transfer. If you do not see the funds in your account within the next 24-48 hours, please contact our support team for assistance.</p>

    <h3 style="color: #0056b3;">Important Reminder</h3>
    <p>We advise you to review the terms of the loan and ensure timely repayments. This will help you maintain a good credit score and avoid any penalties or fees. If you have any questions about repayment schedules, please reach out to us.</p>

    <h3 style="color: #0056b3;">Need Assistance?</h3>
    <p>If you have any questions or require further support, feel free to contact our support team at <a href="mailto:support@dhaniloan.in">support@dhaniloan.in</a> or call us at <strong>[Support Phone Number]</strong>.</p>

    <p>Thank you for choosing <strong>Dhani Finance PVT LTD</strong> as your trusted financial partner. We are excited to support you throughout your loan journey and ensure a seamless experience.</p>
</div>
`;
    const totalSteps = [
        {
            status: "application_received",
            text: "Application Received",
            id: 1,
            message: applicationReviewedHtml
        },
        {
            status: "under_process",
            text: "Under Process",
            id: 2,
            message: underProcessHtml
        },
        {
            status: "loan_approved",
            text: "Loan Approved",
            id: 3,
            message: loanApprovedHtml
        },
        {
            status: "pay_processing",
            text: "Pay Processing",
            id: 4,
            message: payProcessingContent
        },
        {
            status: "loan_disbursed",
            text: "Loan Disbursed",
            id: 5,
            message: loanDisbursedHtml
        }
    ];
    const updateSteps = (direction)=>{
        if (direction === "next" && currentStep < totalSteps.length) {
            setCurrentStep((prevStep)=>prevStep + 1);
        } else if (direction === "prev" && currentStep > 1) {
            setCurrentStep((prevStep)=>prevStep - 1);
        }
    };
    const fetchApplication = async ()=>{
        try {
            // Reference to the document in the "queries" collection
            let colRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$config$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], "queries", id);
            // Fetch the document snapshot
            let dataSnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(colRef);
            if (dataSnapshot.exists()) {
                // Access the data of the document using .data()
                const data = dataSnapshot.data();
                console.log(data, "Data Current Application");
                // Update the state with the document data
                setCurrentApplication(data);
                // Find the current stage based on the application status
                let currentStage = totalSteps.find((a)=>a.status === data.applicationstatus);
                // Update the current step state if the stage was found
                if (currentStage) {
                    setCurrentStep(currentStage.id);
                } else {
                    console.log("Current stage not found.");
                }
            } else {
                console.log("No such document!");
            }
        } catch (err) {
            console.log("Error fetching application:", err);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProgressBar.useEffect": ()=>{
            fetchApplication();
        }
    }["ProgressBar.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProgressBar.useEffect": ()=>{
            document.getElementById("message_content").innerHTML = totalSteps[currentStep].message;
        }
    }["ProgressBar.useEffect"], [
        currentStep
    ]);
    // Only render content when `currentApplication` is available
    if (!currentApplication) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/src/app/_components/ProgressBar/page.js",
            lineNumber: 227,
            columnNumber: 16
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "main-wrapper",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "steps-wrapper",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "steps",
                        children: [
                            totalSteps.map((step, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        display: "flex",
                                        flexDirection: "column",
                                        alignItems: "center",
                                        fontSize: "0.9rem",
                                        textAlign: "center",
                                        gap: 12
                                    },
                                    className: "step-wrapper",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                height: "4vh",
                                                width: "4vh",
                                                fontSize: "2vh"
                                            },
                                            className: `step ${index < currentStep ? "active" : ""}`,
                                            children: index + 1
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                            lineNumber: 237,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            style: {
                                                width: "100%",
                                                marginTop: 5,
                                                marginTop: 22,
                                                fontSize: "2vh",
                                                lineHeight: 1
                                            },
                                            className: `${index < currentStep ? "step-text" : ""}`,
                                            children: step.text
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                            lineNumber: 242,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, step.id, true, {
                                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                    lineNumber: 236,
                                    columnNumber: 29
                                }, this)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "progress-bar",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "progress",
                                    style: {
                                        width: `${(currentStep - 1) / (totalSteps.length - 1) * 100}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                    lineNumber: 246,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                lineNumber: 245,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/ProgressBar/page.js",
                        lineNumber: 234,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                    lineNumber: 233,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                lineNumber: 232,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "message_content",
                className: "message_content",
                ref: messageDivRef
            }, void 0, false, {
                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                lineNumber: 273,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
};
_s(ProgressBar, "vI+5oKA9zxAGcWqNWdaRCdjSADw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = ProgressBar;
const __TURBOPACK__default__export__ = ProgressBar;
var _c;
__turbopack_refresh__.register(_c, "ProgressBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/status/[id]/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$ProgressBar$2f$page$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/_components/ProgressBar/page.js [app-client] (ecmascript)");
"use client";
;
;
const ProgressPage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "wrapper",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "wptb-contact-wrapper style2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            margin: "2px 10px",
                            color: "#0056b3"
                        },
                        children: "Loan Application Status"
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/[id]/page.js",
                        lineNumber: 8,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container",
                        bis_skin_checked: 1,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row",
                            bis_skin_checked: 1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$ProgressBar$2f$page$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/status/[id]/page.js",
                                lineNumber: 11,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/status/[id]/page.js",
                            lineNumber: 10,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/[id]/page.js",
                        lineNumber: 9,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/status/[id]/page.js",
                lineNumber: 7,
                columnNumber: 13
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/status/[id]/page.js",
            lineNumber: 6,
            columnNumber: 9
        }, this)
    }, void 0, false);
};
_c = ProgressPage;
const __TURBOPACK__default__export__ = ProgressPage;
var _c;
__turbopack_refresh__.register(_c, "ProgressPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/status/[id]/page.js [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_724d65._.js.map