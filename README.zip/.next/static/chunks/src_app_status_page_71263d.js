(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_status_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_status_page_71263d.js",
  "chunks": [
    "static/chunks/_87eade._.js",
    "static/chunks/src_app__components_ProgressBar_progress_12e1f6.css"
  ],
  "source": "dynamic"
});
