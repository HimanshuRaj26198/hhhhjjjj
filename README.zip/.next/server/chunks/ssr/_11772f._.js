module.exports = {

"[project]/src/app/_components/ProgressBar/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const ProgressBar = ()=>{
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const messageDivRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    let payProcessingContent = `<div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h2 style="color: #0056b3;">Important Update: Next Steps for Your Loan Disbursement</h2>
    
    <p>Dear <strong>[Applicant's Name]</strong>,</p>
    
    <p>Congratulations! We are pleased to inform you that your loan application has been reviewed by our team and is currently under process. To ensure the smooth disbursement of your loan, there are a few critical steps to complete.</p>
    
    <h3 style="color: #0056b3;">Mandatory Fees for Loan Disbursement</h3>
    <p>To proceed with the loan disbursement, it is essential to pay the following fees:</p>
    
    <ol>
        <li>
            <strong>Processing Fee</strong>: This fee covers the administrative costs associated with handling and processing your loan application.
            <ul>
                <li><strong>Amount:</strong> [Insert Processing Fee Amount]</li>
                <li><strong>Purpose:</strong> Ensures that all necessary documentation, evaluation, and verification are conducted accurately and efficiently.</li>
            </ul>
        </li>
        <li>
            <strong>Insurance Fee</strong>: This fee provides coverage to secure your loan and mitigate risks.
            <ul>
                <li><strong>Amount:</strong> [Insert Insurance Fee Amount]</li>
                <li><strong>Purpose:</strong> Safeguards both you and the lender in case of unforeseen circumstances.</li>
            </ul>
        </li>
    </ol>
    
    <p><strong>Please note that the payment of these fees is mandatory and must be completed before your loan can be disbursed.</strong></p>
    
    <h3 style="color: #0056b3;">How to Make the Payments</h3>
    <ol>
        <li>
            <strong>Processing Fee Payment:</strong>
            <ul>
                <li>Transfer the fee amount to the following account:</li>
                <ul>
                    <li><strong>Account Name:</strong> [Insert Account Name]</li>
                    <li><strong>Account Number:</strong> [Insert Account Number]</li>
                    <li><strong>Bank Name:</strong> [Insert Bank Name]</li>
                    <li><strong>IFSC Code:</strong> [Insert IFSC Code]</li>
                </ul>
                <li>Once the payment is made, kindly send a confirmation receipt to <a href="mailto:[Support Email]">[Support Email]</a>.</li>
            </ul>
        </li>
        <li>
            <strong>Insurance Fee Payment:</strong>
            <ul>
                <li>The insurance fee can be paid using any of the following methods:</li>
                <ul>
                    <li><strong>Online Payment Gateway:</strong> <a href="[Insert Link]">Click here</a></li>
                    <li><strong>Direct Transfer:</strong> Use the same bank details as mentioned above.</li>
                </ul>
                <li>After the payment, please upload the proof of payment on your loan dashboard or email it to <a href="mailto:[Support Email]">[Support Email]</a>.</li>
            </ul>
        </li>
    </ol>
    
    <h3 style="color: #0056b3;">Next Steps After Payment</h3>
    <p>
        Once the fees are successfully received, our team will update your application status within <strong>24 hours</strong>.
        A representative from our support team will contact you to confirm the details and provide further instructions regarding the disbursement process.
    </p>
    
    <p>We emphasize the importance of completing these payments at the earliest to avoid delays in your loan disbursement. Should you have any questions or require assistance with the payment process, feel free to contact our customer support team at <a href="mailto:[Support Email]">[Support Email]</a> or call us at [Support Phone Number].</p>
    
    <p>Thank you for choosing <strong>[Your Company Name]</strong> as your trusted financial partner. We look forward to serving you.</p>
</div>
`;
    const totalSteps = [
        {
            status: "application_received",
            text: "Application Received",
            id: 1,
            message: "Thank you for submitting your application. We are pleased to inform you that it has been successfully received and is currently under review by our loan department. Please allow some time for the necessary assessments and processing to be completed. Once your loan status has been updated, a member of our team will contact you to provide further information or discuss the next steps. We appreciate your patience and understanding during this process."
        },
        {
            status: "under_process",
            text: "Under Process",
            id: 2,
            message: "Congratulations! Your loan appliated has been reviewd by our team and is now under process please wait a while, your status will be updated within 24 hours and then our support team will contact you soon."
        },
        {
            status: "pay_processing",
            text: "Pay Processing",
            id: 2,
            message: "Congratulations! Your loan appliated has been reviewd by our team and is now under process please wait a while, your status will be updated within 24 hours and then our support team will contact you soon."
        },
        {
            status: "loan_approved",
            text: "Loan Approved",
            id: 3,
            message: payProcessingContent
        },
        {
            status: "loan_disbursed",
            text: "Loan Disbursed",
            id: 4,
            message: ""
        }
    ];
    const updateSteps = (direction)=>{
        if (direction === "next" && currentStep < totalSteps.length) {
            setCurrentStep((prevStep)=>prevStep + 1);
        } else if (direction === "prev" && currentStep > 1) {
            setCurrentStep((prevStep)=>prevStep - 1);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
    // document.getElementById("message_content").innerHTML = htmlCOntent;
    // messageDivRef.innerHTML = htmlCOntent
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "main-wrapper",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "steps-wrapper",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "steps",
                        children: [
                            totalSteps.map((step, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        display: "flex",
                                        flexDirection: "column",
                                        alignItems: "center",
                                        fontSize: "0.9rem",
                                        textAlign: "center",
                                        gap: 12
                                    },
                                    className: "step-wrapper",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                height: "4vh",
                                                width: "4vh",
                                                fontSize: "2vh"
                                            },
                                            className: `step ${index < currentStep ? "active" : ""}`,
                                            children: index + 1
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                            lineNumber: 108,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            style: {
                                                width: "100%",
                                                marginTop: 5,
                                                marginTop: 22,
                                                fontSize: "2vh",
                                                lineHeight: 1
                                            },
                                            className: `${index < currentStep ? "step-text" : ""}`,
                                            children: step.text
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                            lineNumber: 113,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, step.id, true, {
                                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                    lineNumber: 107,
                                    columnNumber: 29
                                }, this)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "progress-bar",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "progress",
                                    style: {
                                        width: `${(currentStep - 1) / (totalSteps.length - 1) * 100}%`
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                    lineNumber: 117,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                                lineNumber: 116,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/ProgressBar/page.js",
                        lineNumber: 105,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/ProgressBar/page.js",
                    lineNumber: 104,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                lineNumber: 103,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "message_content",
                className: "message_content",
                ref: messageDivRef
            }, void 0, false, {
                fileName: "[project]/src/app/_components/ProgressBar/page.js",
                lineNumber: 144,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = ProgressBar;
}}),
"[project]/src/app/status/[id]/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$ProgressBar$2f$page$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/_components/ProgressBar/page.js [app-ssr] (ecmascript)");
"use client";
;
;
const ProgressPage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "wrapper",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "wptb-contact-wrapper style2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            margin: "2px 10px",
                            color: "#0056b3"
                        },
                        children: "Loan Application Status"
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/[id]/page.js",
                        lineNumber: 8,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container",
                        bis_skin_checked: 1,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row",
                            bis_skin_checked: 1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$ProgressBar$2f$page$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/app/status/[id]/page.js",
                                lineNumber: 11,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/status/[id]/page.js",
                            lineNumber: 10,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/[id]/page.js",
                        lineNumber: 9,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/status/[id]/page.js",
                lineNumber: 7,
                columnNumber: 13
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/status/[id]/page.js",
            lineNumber: 6,
            columnNumber: 9
        }, this)
    }, void 0, false);
};
const __TURBOPACK__default__export__ = ProgressPage;
}}),
"[project]/src/app/status/[id]/page.js [app-rsc] (ecmascript, Next.js server component, client modules ssr)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
module.exports = __turbopack_require__("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}}),

};

//# sourceMappingURL=_11772f._.js.map