const Loading = () => {
    return <div style={{ width: "100%", height: "100vh", display: "flex", justifyContent: "center", alignItems: "center" }} >
        <img src="/assets/images/Loading_2(1).gif" />
    </div>
}

export default Loading;